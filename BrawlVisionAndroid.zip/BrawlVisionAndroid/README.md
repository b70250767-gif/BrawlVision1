# Brawl Vision — Android

A standalone visual aim/ESP-style training demo. It draws a simulated arena, four practice targets, target markers, distance labels, a nearest-target guide line, and adjustable sensitivity.

## Build
1. Open this folder in Android Studio (Ladybug or newer).
2. Allow Gradle sync.
3. Select an Android device or emulator (Android 6.0+).
4. Press Run.

## Controls
- Tap the ESP tile to show/hide target boxes and distance labels.
- Tap AIM ASSIST to show/hide the guide line and radius.
- Drag across the sensitivity slider to adjust its visual radius.
- Tap the arena to cycle the selected target.

This is a standalone training simulator. It does not read, modify, inject into, or overlay the Brawl Stars app.
